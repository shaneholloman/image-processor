"""
Image Indexer

This script processes various image types in a specified folder, generates descriptions
using the LLaVA model, and stores the descriptions in a CSV file.
It uses Ollama for image description generation.

Usage:
    python image_indexer.py

Requirements:
    - ollama
    - pandas
    - Pillow

Version: 0.9.6
Author: AI Assistant
"""

import os
from io import BytesIO
import glob
from typing import List
from ollama import Client
import pandas as pd
from PIL import Image

# Constants
SUPPORTED_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".bmp")
CSV_FILENAME = "image_descriptions.csv"
IMAGE_FOLDER = "./Pictures"
MODEL_NAME = "llava"
PROMPT = (
    "Describe this image and make sure to include anything notable about it "
    "(include text you see in the image):"
)


def load_or_create_dataframe(filename: str) -> pd.DataFrame:
    """
    Load an existing DataFrame from a CSV file or create a new one if the file doesn't exist.

    Args:
        filename (str): The name of the CSV file.

    Returns:
        pd.DataFrame: The loaded or newly created DataFrame.
    """
    if os.path.isfile(filename):
        return pd.read_csv(filename)
    return pd.DataFrame(columns=["image_file", "description"])


def get_image_files(folder_path: str) -> List[str]:
    """
    Get a list of supported image files in the specified folder.

    Args:
        folder_path (str): The path to the folder containing images.

    Returns:
        List[str]: A sorted list of supported image file paths.
    """
    image_files = []
    for ext in SUPPORTED_EXTENSIONS:
        image_files.extend(glob.glob(os.path.join(folder_path, f"*{ext}")))
    return sorted(image_files)


def process_image(image_file: str, df: pd.DataFrame) -> None:
    """
    Process a single image file, generate a description, and add it to the DataFrame.

    Args:
        image_file (str): The path to the image file.
        df (pd.DataFrame): The DataFrame to store the image description.
    """
    print(f"\nProcessing {image_file}\n")
    with Image.open(image_file) as img:
        with BytesIO() as buffer:
            img.save(buffer, format="PNG")  # Convert all images to PNG for consistency
            image_bytes = buffer.getvalue()

    full_response = ""
    client = Client()

    try:
        generator = client.generate(
            model=MODEL_NAME, prompt=PROMPT, images=[image_bytes], stream=True
        )
        for response in list(generator):
            if isinstance(response, dict) and "response" in response:
                print(response["response"], end="", flush=True)
                full_response += response["response"]
            else:
                print(f"Unexpected response format: {response}")

        # Add a new row to the DataFrame
        df.loc[len(df)] = [image_file, full_response]
    except (ValueError, KeyError, TypeError) as e:
        print(f"Error processing image {image_file}: {str(e)}")


def main():
    """
    Main function to orchestrate the image processing workflow.
    """
    df = load_or_create_dataframe(CSV_FILENAME)
    image_files = get_image_files(IMAGE_FOLDER)

    print(f"Sample image files: {image_files[:3]}")
    print("Current DataFrame head:")
    print(df.head())

    for image_file in image_files:
        if image_file not in df["image_file"].values:
            process_image(image_file, df)

    # Save the DataFrame to a CSV file
    df.to_csv(CSV_FILENAME, index=False)


if __name__ == "__main__":
    main()
