# TODO

<https://claude.ai/chat/e6a1a4b0-68ef-4844-993c-25d49e841913>

## General project wide items

- when importing image for processing, understand when to use bytes and when to use base64 encoding. However this may be a thing of the past as that was a PIL centric issue.
- learn to read and manipulate sqlite databases,. This is working, I just need to learn more on this.

## Test Suite

- test suite works so far
- test suite needs to be expanded to include more tests
  - include sqlite tests
  - read existing image meta test
- integrate ollama via github workflow runners or another LLM thats already in the GitHUb ecosystem/marketplace
- Lint issues need to be resolved for test_integration.py
